Known issues:

On windows WADs can't be unpacked 
